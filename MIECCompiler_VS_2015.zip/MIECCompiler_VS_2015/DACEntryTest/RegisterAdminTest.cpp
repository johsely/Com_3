#include "stdafx.h"
#include "CppUnitTest.h"
#include "../MIECCompiler/DACEntry.h"
#include "../MIECCompiler/RegisterAdmin.h"
#include <iostream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace std;

namespace DACEntryTest
{
	TEST_CLASS(RegisterAdminTest)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
			RegisterAdmin regAdmin;

		}


	};
}