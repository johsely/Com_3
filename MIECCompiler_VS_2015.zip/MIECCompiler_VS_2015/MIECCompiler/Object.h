/**
* @file   Object.h
* @Author Christoph Haslinger, Johannes Selymes
* @Date   Februar , 2016
* @brief  Mandatory object class
*
*
*/
#ifndef MIEC_OBJECT_H
#define MIEC_OBJECT_H

class Object {
protected:
	Object(){};
public:
	virtual ~Object(){};
};

#endif